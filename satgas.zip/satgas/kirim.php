<?php
include("koneksi_arduino.php");
$id_alat = $_GET['id_alat'];
$soil1 = $_GET['soil1'];
$soil2 = $_GET['soil2'];
$ketinggian1 = $_GET['ketinggian1'];
$ketinggian2 = $_GET['ketinggian2'];

$ketentuan_ketinggian1 = 2;
$ketentuan_ketinggian2 = 2;

//status sawah 1 
if ($soil1 > 600) {
    $status1 = "SAWAH KERING";
} elseif ($soil1 < 600 && $ketinggian1 < $ketentuan_ketinggian1) {
    $status1 = "PROSES PENGAIRAN";
} elseif ($soil1 < 600 && $ketinggian1 > $ketentuan_ketinggian1) {
    $status1 = "AIR PENUH";
}

//status sawah 
if ($soil2 < 10) {
    $status2 = "SAWAH KERING";
} elseif ($soil2 > 10 && $ketinggian2 < $ketentuan_ketinggian2) {
    $status2 = "PROSES PENGAIRAN";
} elseif ($soil2 > 10 && $ketinggian2 > $ketentuan_ketinggian2) {
    $status2 = "AIR PENUH";
}

mysqli_query($konek, "INSERT INTO datasensor(id_alat,soil1,soil2,ketinggian1,ketinggian2,status1,status2,tgl) VALUES('$id_alat','$soil1','$soil2','$ketinggian1',
'$ketinggian2','$status1','$status2',NOW())");

$sql = "select * from switch where id='mode'";
$sql1 = "select * from switch where id='switch1'";
$sql2 = "select * from switch where id='switch2'";
$sql3 = "select * from switch where id='switch3'";
$trigger = "SELECT MAX(id_data) as id_data FROM `datasensor`";
$hapus = "TRUNCATE TABLE `datasensor`";

$result = mysqli_query($konek, $sql);
$result1 = mysqli_query($konek, $sql1);
$result2 = mysqli_query($konek, $sql2);
$result3 = mysqli_query($konek, $sql3);
$result4 = mysqli_query($konek, $trigger);


if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    echo ',' . $row['value'];
}

if (mysqli_num_rows($result1) > 0) {
    $row = mysqli_fetch_assoc($result1);
    echo ',' . $row['value'];
}

if (mysqli_num_rows($result2) > 0) {
    $row = mysqli_fetch_assoc($result2);
    echo ',' . $row['value'];
}

if (mysqli_num_rows($result3) > 0) {
    $row = mysqli_fetch_assoc($result3);
    echo ',' . $row['value'];
}

//trigger mengosongkan table jika data sudah melewati limit yang di tentukan
if (mysqli_num_rows($result3) > 0) {
    $row = mysqli_fetch_assoc($result4);

    //echo id data sekarang
    //echo ',' . $row['id_data'];

    if ($row['id_data'] > 500) {
        //echo "Turcate";
        $result5 = mysqli_query($konek, $hapus);
    }
}
