<?php

require_once('database.php');

$statement = $connection->query('SELECT * FROM switch');
//$statement2 = $connection->query('SELECT * FROM datasensor'); //sing iki

header('Content-Type: application/json');
echo json_encode($statement->fetchAll(PDO::FETCH_ASSOC), JSON_NUMERIC_CHECK);
