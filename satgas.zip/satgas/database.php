<?php
// $hostname = 'localhost';
// $username = 'root';
// $password = '';
// $database = 'satgas';
$hostname = 'localhost';
$username = 'u1047932_admin';
$password = 'admin';
$database = 'u1047932_satgas';
try {
    $connection = new PDO("mysql:host=${hostname};dbname=${database}", $username, $password);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $ex) {
    echo 'Error: ' . $ex->getMessage();
}
