<?php
$hostname = 'localhost';
$username = 'u1047932_admin';
$password = 'admin';
$database = 'u1047932_satgas';

// $db_host = "localhost"; //:3306
// $db_user = "root";
// $db_pass = "";
// $db_name = "satgas";

$conn = mysqli_connect($hostname, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo 'Gagal melakukan koneksi ke Database : ' . mysqli_connect_error();
} else {
    //	echo "berhasil";
}
