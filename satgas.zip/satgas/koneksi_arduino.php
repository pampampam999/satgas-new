<?php
include 'koneksi.php';
$servername = $hostname;
$database1 = $database;
$username1 = $username;
$password1 = $password;
$konek = mysqli_connect($servername, $username1, $password1, $database1);
if ($konek != false) {
    echo "11";
} else {
    echo "00";
}
