<?php
include "koneksi.php";
$sqlCommand2 = "SELECT * FROM `datasensor` ORDER BY `id_data` DESC LIMIT 1";
$query2 = mysqli_query($conn, $sqlCommand2);
$row1 = mysqli_fetch_row($query2);
$id_data = $row1[0];
$id_alat = $row1[1];
$soil1 = $row1[2];
$soil2 = $row1[3];
$ketinggian1 = $row1[4];
$ketinggian2 = $row1[5];
$status1 = $row1[6];
$status2 = $row1[7];

?>

<!-- Main Content -->
<script type="text/javascript">
    var auto_refresh = setInterval(
        function() {
            $('.index').load('dashboard.php');
        }, 500); // refresh setiap 10000 milliseconds
</script>

<div id="content" class="index">
    <!-- Topbar -->


    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard <h4><?php echo $id_data; ?></h4>
            </h1>


        </div>

        <!-- Content Row -->
        <div class="row">

        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h4 class="m-0 font-weight-bold text-primary" style="text-align:center;">Notification</h4>
                    </div>
                      <div class="card-body sensor" style="text-align:center;">

                        <?php if ($status1 == "AIR PENUH" && $status2 == "AIR PENUH") {
                        ?>
                            <div class="alert alert-success" role="alert">
                                 SAWAH1&2 = PENGAIRAN SELESAI
                                
                            </div>
                        <?php
                        } elseif ($status2 == "AIR PENUH") { ?>
                            <hr>
                            <div class="alert alert-success" role="alert">
                                SAWAH2 PENGAIRAN SELESAI
                            </div>
                        <?php
                        } elseif ($status1 == "AIR PENUH") {
                        ?>
                            <div class="alert alert-success" role="alert">
                               SAWAH1 PENGAIRAN SELESAI
                            </div>
                        <?php
                        } else {
                            echo "<h2>--</h2>";
                        }
                        ?>

                    </div>
                </div>
            </div>


        </div>
        <div class=" row">
            <div class="col-md-6">
                <div class="card shadow mb-4">
                    <!-- Card Header - Accordion -->
                    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
                        <h6 class="m-0 font-weight-bold text-primary">AREA 1</h6>
                    </a>
                    <!-- Card Content - Collapse -->
                    <div class="collapse show" id="collapseCardExample">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card border-left-primary shadow h-100 py-2">
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col mr-2">
                                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                        Kelembaban Tanah</div>
                                                    <div class="h5 mb-0 font-weight-bold text-gray-800"> <?php echo $soil1; ?></div>
                                                    <!--  <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input" id="switch1" name="switch1">
                                                <label class="custom-control-label" for="switch1">Pintu 1</label>
                                            </div>-->
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fas fa-map-marker fa-2x text-gray-300"></i>
                                                    </sssssdiv>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="card border-left-warning shadow h-100 py-2">
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col mr-2">
                                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                        Ketinggian</div>
                                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $ketinggian1; ?></div>
                                                    <!--  <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input" id="switch1" name="switch1">
                                                <label class="custom-control-label" for="switch1">Pintu 1</label>
                                            </div>-->
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fas fa-water fa-2x text-gray-300"></i>
                                                    </sssssdiv>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 my-3">
                                    <div class="card border-left-warning shadow h-100 py-2">
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col mr-2">
                                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                        STATUS</div>
                                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $status1; ?></div>
                                                    <!--  <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input" id="switch1" name="switch1">
                                                <label class="custom-control-label" for="switch1">Pintu 1</label>
                                            </div>-->
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fas fa-exclamation-circle fa-2x text-gray-300"></i>
                                                    </sssssdiv>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card shadow mb-4">
                    <!-- Card Header - Accordion -->
                    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
                        <h6 class="m-0 font-weight-bold text-primary">AREA 2</h6>
                    </a>
                    <!-- Card Content - Collapse -->
                    <div class="collapse show" id="collapseCardExample">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card border-left-primary shadow h-100 py-2">
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col mr-2">
                                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                        Kelembaban Tanah</div>
                                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $soil2; ?></div>
                                                    <!--  <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input" id="switch1" name="switch1">
                                                <label class="custom-control-label" for="switch1">Pintu 1</label>
                                            </div>-->
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fas fa-map-marker fa-2x text-gray-300"></i>
                                                    </sssssdiv>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="card border-left-warning shadow h-100 py-2">
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col mr-2">
                                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                        Ketinggian</div>
                                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $ketinggian2; ?></div>
                                                    <!--  <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input" id="switch1" name="switch1">
                                                <label class="custom-control-label" for="switch1">Pintu 1</label>
                                            </div>-->
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fas fa-water fa-2x text-gray-300"></i>
                                                    </sssssdiv>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 my-3">
                                    <div class="card border-left-warning shadow h-100 py-2">
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col mr-2">
                                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                        STATUS</div>
                                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $status2; ?></div>
                                                    <!--  <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input" id="switch1" name="switch1">
                                                <label class="custom-control-label" for="switch1">Pintu 1</label>
                                            </div>-->
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fas fa-exclamation-circle fa-2x text-gray-300"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Collapsable Card Example -->

</div>
<!-- Earnings (Monthly) Card Example -->
<div class="row">

    <!-- Content Row -->




    <!-- Content Row -->

    <div class="row">

        <!-- Area Chart -->



        <!-- Content Row -->


    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->