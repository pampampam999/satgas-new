<?php
require_once('database.php');

$statement = $connection->prepare('UPDATE `switch` SET `value` = ? WHERE `id` = ?');
echo $statement->execute(array($_GET['value'], $_GET['name'])) ? 'OK' : 'ERROR';
