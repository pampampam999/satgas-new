<?php include "koneksi.php";
$sqlCommand2 = "SELECT value FROM `switch` WHERE id='mode'";
$query2 = mysqli_query($conn, $sqlCommand2);
$row1 = mysqli_fetch_row($query2);
$value = $row1[0];


?>
<?php include "nav.php"; ?>

<!-- Main Content -->
<div id="content">
    <!-- Topbar -->
    <?php include "head.php" ?>

    <!-- Main Content -->
    <div id="content">

        <!-- Topbar -->

        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Settings</h1>

            </div>

            <!-- Content Row -->
            <div class="row">

            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h4 class="m-0 font-weight-bold text-primary" style="text-align:center;">Set Mode</h4>
                        </div>
                        <form action="insert_mode.php" method="POST">
                            <div class="card-body" style="text-align:center;">
                                <!--  <h5 class="m-0 font-weight-bold text-primary">--</h5>-->
                                <div class="form-check form-check-inline">
                                    <h4>
                                        <input class="form-check-input" type="radio" name="value" id="inlineRadio1" value="0" <?php if ($value == 0) {
                                                                                                                                    echo "checked";
                                                                                                                                } ?>>
                                        <label class="form-check-label" for="inlineRadio1">Otomatis</label>
                                    </h4>

                                </div>
                                <div class="form-check form-check-inline">
                                    <h4>
                                        <input class="form-check-input" type="radio" name="value" id="inlineRadio2" value="1" <?php if ($value == 1) {
                                                                                                                                    echo "checked";
                                                                                                                                } ?>>
                                        <label class="form-check-label" for="inlineRadio2">Manual</label>
                                    </h4>
                                </div>
                                <br>
                                <button type="submit" class="btn btn-outline-primary col-md-2">SET</button>

                        </form>

                        <?php
                        if ($value == 0) {
                            $set = "disabled";
                        ?>
                            <hr>
                            <div class="alert alert-warning" role="alert">
                                Switch Disabled
                            </div>
                        <?php
                        } elseif ($value == 1) {
                            $set = "";
                        }
                        ?>

                    </div>
                </div>
            </div>

        </div>
        <div class=" row">
            <div class="col-md-12">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h4 class="m-0 font-weight-bold text-primary" style="text-align:center;">Control</h4>
                    </div>
                    <div class="card-body" style="text-align:center;">
                        <!--  <h5 class="m-0 font-weight-bold text-primary">--</h5>-->
                        <div class="row">
                            <div class="col-md-4">
                                <div class="card border-bottom-success shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">

                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input" id="switch1" name="switch1" <?php echo $set; ?>>
                                                    <label class="custom-control-label" for="switch1">Pintu 1</label>
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-sign-in-alt fa-2x text-gray-300"></i>
                                                </sssssdiv>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-4">
                                <div class="card border-bottom-success shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">

                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input" id="switch2" name="switch2" <?php echo $set; ?>>
                                                    <label class="custom-control-label" for="switch2">Pintu 2</label>
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-sign-in-alt fa-2x text-gray-300"></i>
                                                </sssssdiv>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-4">
                                <div class="card border-bottom-danger shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input" id="switch3" name="switch3" <?php echo $set; ?>>
                                                    <label class="custom-control-label" for="switch3">Pompa</label>
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-charging-station fa-2x text-gray-300"></i>
                                                </sssssdiv>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>

        <!-- Collapsable Card Example -->

    </div>
</div>
<!-- Earnings (Monthly) Card Example -->
<div class="row">

    <!-- Content Row -->




    <!-- Content Row -->

    <div class="row">

        <!-- Area Chart -->



        <!-- Content Row -->


    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
</div>
<!--js saklar-->
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
<script>
    $('input[type=checkbox]').on('change', function(event) {
        $.get('set-data.php', {
            name: event.target.name,
            value: event.target.checked + 0,
        }, function(data) {
            if (data === 'OK')
                console.log('update success')
            else
                alert('update error!')
        });
    })

    function getData() {
        $.getJSON('get-data.php', function(data) {
            $.each(data, function(key, value) {
                $(`#${value['id']}`).prop('checked', value['value'])
            })
        })
    }

    getData()
    setInterval(getData, 2500)
</script>
<!-- Footer -->
<?php include "footer.php"; ?>