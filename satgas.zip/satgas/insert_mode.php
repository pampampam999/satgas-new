<?php
include 'koneksi.php';
// menyimpan data kedalam variabel

$value  = $_POST['value'];

// query SQL untuk insert data
//$query="UPDATE mahasiswa SET nim='$nim',nama='$nama',jurusan='$jurusan',jenis_kelamin='$jenis_kelamin',alamat='$alamat' where id_mahasiswa='$id_mahasiswa'";
$query = "UPDATE `switch` SET `value` ='$value' where id='mode'";
mysqli_query($conn, $query);
// mengalihkan ke halaman index.php
header("location:settings.php");
