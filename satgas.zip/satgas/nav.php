<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SATGAS</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient sidebar sidebar-dark accordion" id="accordionSidebar" style="background: #C3EDFB;">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-icon rotate-n-15">

                    <i>
                        <img src="satgas3.png" width="40" height="40">
                    </i>
                </div>
                <div class="sidebar-brand-text mx-3 text-gray-700">SATGAS</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active text-gray-700">
                <a class="nav-link text-gray-700" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt text-gray-700"></i>
                    <span>DASHBOARD</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider text-gray-700">

            <!-- Heading -->
            <div class="sidebar-heading text-gray-700">
                Interface
            </div>

            <!-- Nav Item - Pages Collapse Menu -->


            <!-- Nav Item - Utilities Collapse Menu fas fa-fw fa-cog -->


            <!--   <li class="nav-item ">
                <a class="nav-link text-gray-700" href="settings.php">
                    <i class="fas fa-fw fa-dungeon text-gray-700"></i>
                    <span>Pintu</span></a>
            </li>

         <li class="nav-item ">
                <a class="nav-link text-gray-700" href="settings.php">
                    <i class="fas fa-fw fa-route text-gray-700"></i>
                    <span>Rute</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link text-gray-700" href="blank.html">
                    <i class="fas fa-fw fa-table text-gray-700"></i>
                    <span>Sawah</span></a>
            </li>-->
            <li class="nav-item ">
                <a class="nav-link text-gray-700" href="settings.php">
                    <i class="fas fa-fw fa-cog text-gray-700"></i>
                    <span>Settings</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading text-gray-700">
                Addons
            </div>

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item text-gray-700">
                <a class="nav-link collapsed text-gray-700" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-folder text-gray-700"></i>
                    <span>Pages </span>
                    <h9 class="badge badge-success">Comming Soon</h9>
                </a>
                <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Login Screens:</h6>
                        <a class="collapse-item" href="404.html">Login</a>
                        <a class="collapse-item" href="404.html">Register</a>
                        <a class="collapse-item" href="404.html">Forgot Password</a>
                        <div class="collapse-divider"></div>
                        <h6 class="collapse-header">Other Pages:</h6>
                        <a class="collapse-item" href="404.html">404 Page</a>
                        <a class="collapse-item" href="404.html">Blank Page</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Charts -->




        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">